NETLIFY DROP — Oct 5, 2026 (office-network sign-in)

Upload everything in this folder to the same place you upload index.html, KEEPING the folders:

  netlify.toml                              ← repo root (used when Netlify's Base directory is the root)
  portal_site/netlify.toml                  ← used when Netlify's Base directory is portal_site
  portal_site/netlify/functions/net.js      ← the function itself (this is the one that was missing)
  portal_site/office-beacon.html
  portal_site/admin.html
  portal_site/index.html

Both netlify.toml files are fine to have — Netlify only reads the one at its Base directory.

Check after the deploy: https://portal.jmbvirtuals.com/.netlify/functions/net
  → shows your IP and "signed": true.
